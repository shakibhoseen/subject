package com.shakib.bloodbank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class VerificationOtp extends AppCompatActivity implements TextWatcher {
    EditText input1, input2, input3, input4, input5, input6;
    Button verifyBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification_otp);

        verifyBtn = findViewById(R.id.submit_otp_id);
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        input3 = findViewById(R.id.input3);
        input4 = findViewById(R.id.input4);
        input5 = findViewById(R.id.input5);
        input6 = findViewById(R.id.input6);

        input1.addTextChangedListener(this);
        input2.addTextChangedListener(this);
        input3.addTextChangedListener(this);
        input4.addTextChangedListener(this);
        input5.addTextChangedListener(this);

        String backendOtp = getIntent().getStringExtra("backendOtp");

        verifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (input1.getText().toString().trim().isEmpty() || input2.getText().toString().trim().isEmpty() ||
                        input1.getText().toString().trim().isEmpty() || input2.getText().toString().trim().isEmpty() ||
                        input1.getText().toString().trim().isEmpty() || input2.getText().toString().trim().isEmpty()) {

                    Toast.makeText(VerificationOtp.this, "please enter otp", Toast.LENGTH_SHORT).show();
                   return;
                }

                if (backendOtp==null){
                    Toast.makeText(VerificationOtp.this, "please check internet conncetion", Toast.LENGTH_SHORT).show();
                    return;
                }
                String userOtp = input1.getText().toString()+ input2.getText().toString()+
                        input3.getText().toString()+ input4.getText().toString()+
                        input1.getText().toString()+ input1.getText().toString();
                        
                verifyOtp(backendOtp, userOtp);
            }
        });

    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        TextView text = (TextView) getCurrentFocus();

        if (text != null && text.length() > 0) {
            View next = text.focusSearch(View.FOCUS_RIGHT); // or FOCUS_FORWARD
            if (next != null)
                next.requestFocus();


        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    private void verifyOtp(String otpBakend, String otpUser) {
        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(
                otpBakend, otpUser
        );

        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    Toast.makeText(VerificationOtp.this, "Success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(VerificationOtp.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else {
                    Toast.makeText(VerificationOtp.this, "" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}