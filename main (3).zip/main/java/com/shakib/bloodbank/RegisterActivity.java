package com.shakib.bloodbank;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.shakib.bloodbank.ui.Model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class RegisterActivity extends AppCompatActivity {

    List<String>  zillaArr, upzilaArry;
    List<String> bivagArr;
    ArrayAdapter<String> itemsAdapter, zillaAdapter, upzillaAdapter;
    List<Model>  zillaModels, upzillaModels;
    Spinner spinnerDiv, spinnerDis, spinnerUpzila;
    Button registerBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        bivagArr = new ArrayList<>();
        zillaArr = new ArrayList<>();
        zillaModels = new ArrayList<>();
        upzilaArry = new ArrayList<>();


        spinnerDiv = findViewById(R.id.spinner_bivag_id);
        spinnerDis = findViewById(R.id.spinner_district_id);
        spinnerUpzila = findViewById(R.id.spinner_upzila_id);
        registerBtn = findViewById(R.id.btn_register);
       /* ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(this ,
                arry ,android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

*/
         itemsAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, bivagArr);
        spinnerDiv.setAdapter(itemsAdapter);
        spinnerDiv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              String  spinTxt = parent.getItemAtPosition(position).toString();

                getZila(String.valueOf(position+1));
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        zillaAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, zillaArr);
        spinnerDis.setAdapter(zillaAdapter);
        spinnerDis.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String  spinTxt = parent.getItemAtPosition(position).toString();

                getUpaZila(zillaModels.get(position).getId());
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        upzillaAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, upzilaArry);
        spinnerUpzila.setAdapter(upzillaAdapter);
        spinnerUpzila.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String  spinTxt = parent.getItemAtPosition(position).toString();

            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, VerificationOtp.class));
            }
        });


     getBivag();
    }

    private void sentOtp(String phone){
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone,
                60,
                TimeUnit.SECONDS,
                RegisterActivity.this,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {

                    }

                    @Override
                    public void onCodeSent(@NonNull String backendOtp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        Intent intent = new Intent(getApplicationContext(), VerificationOtp.class);
                        intent.putExtra("mobile", phone);
                        intent.putExtra("backendOtp", backendOtp);
                        startActivity(intent);
                    }
                }
                );
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void getBivag(){
        String jason ;
        bivagArr.clear();
        try {
            InputStream input = getAssets().open("divisions.json");
            int size = input.available();
            byte [] buffer = new byte[size];
            input.read(buffer);
            input.close();

            jason = new String(buffer, StandardCharsets.UTF_8);
            JSONArray jsonArray = new JSONArray(jason);
            int jsnSize = jsonArray.length();
            for (int i = 0; i < jsnSize; i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                String id = object.optString("id");
                String bn_name = object.optString("bn_name");
               /* Model model = new Model();
                if (!id.isEmpty()){
                    model.setId(id);
                }
                if (!name.isEmpty()){
                    model.setName(name);
                }*/
                bivagArr.add(bn_name);
            }
            itemsAdapter.notifyDataSetChanged();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }




    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void getZila(String divisitionId){

        String jason ;
        zillaArr.clear();
        zillaModels.clear();
        try {
            InputStream input = getAssets().open("districts.json");
            int size = input.available();
            byte [] buffer = new byte[size];
            input.read(buffer);
            input.close();

            jason = new String(buffer, StandardCharsets.UTF_8);
            JSONArray jsonArray = new JSONArray(jason);
            int jsnSize = jsonArray.length();
            for (int i = 0; i < jsnSize; i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                String tepmDiv = object.optString("division_id");

                if (tepmDiv.equals(divisitionId)){
                    String name = object.optString("name");
                    String bn_name = object.optString("bn_name");
                    String id = object.optString("id");
                    zillaArr.add(bn_name);
                    Model model = new Model();
                    model.setName(name);
                    model.setId(id);
                    zillaModels.add(model);
                }


            }
            zillaAdapter.notifyDataSetChanged();
            getUpaZila(zillaModels.get(0).getId());
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }




    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void getUpaZila(String districtId){
        String jason ;
        upzilaArry.clear();
        try {
            InputStream input = getAssets().open("upazilas.json");
            int size = input.available();
            byte [] buffer = new byte[size];
            input.read(buffer);
            input.close();

            jason = new String(buffer, StandardCharsets.UTF_8);
            JSONArray jsonArray = new JSONArray(jason);
            int jsnSize = jsonArray.length();
            for (int i = 0; i < jsnSize; i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                String tepmDiv = object.optString("district_id");
                if (tepmDiv.equals(districtId)){
                    String name = object.optString("bn_name");
                    upzilaArry.add(name);
                }


            }
            upzillaAdapter.notifyDataSetChanged();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }




    }
}